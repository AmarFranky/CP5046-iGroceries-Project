<?php include('header.php'); ?>

<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="#" title="Admin Home" class="tip-bottom"><i class="icon-home"></i> <b>Dashboard</b> </a></div>
  </div>
  <div class="container-fluid">
   	<div class="quick-actions_homepage">
    <ul class="quick-actions">
          <li> <a href="#"> <i class="icon-dashboard"></i> My Dashboard </a> Admin  </li>
          <li> <a href="#"> <i class="icon-shopping-bag"></i> Total Products</a> 0 </li>
          <li> <a href="#"> <i class="icon-money"></i> Total Transactions </a>0 </li>
          <li> <a href="#"> <i class="icon-people"></i> Total Customers </a>0 </li>
     
        </ul>
   </div>

<?php include('footer.php'); ?>